<?php
include "crud_problems_config.php";
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM problems WHERE id='$id'";
    $result = $con->query($sql);
    if ($result == True) {
        $row = $result->fetch_assoc();
        $title = $row['title'];
        $problem_condition = $row['problem_condition'];
    } else {
        echo "Error:" . $sql . "<br>" . $con->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="icon" href="python-logo.png" type="image/x-icon">
    <style>
        textarea {
            background-color: black;
            color: white;
        }

        ::placeholder {
            /* Chrome, Firefox, Opera, Safari 10.1+ */
            color: white;
            opacity: 1;
            /* Firefox */
        }

        :-ms-input-placeholder {
            /* Internet Explorer 10-11 */
            color: white;
        }

        ::-ms-input-placeholder {
            /* Microsoft Edge */
            color: white;
        }

        textarea {
            padding-left: 10px;
            border: 0px;
            width: 100%;
            height: 300px;
            background-color: black;
        }

        textarea {
            resize: none;
        }
    </style>
</head>

<body>    

    <h2>
        <?php
        echo $title;
        ?>
    </h2>
    <div>
        <?php
        echo $problem_condition;
        ?>
    </div>
    <div id="console">
        <form action="submit.php?id=<?php echo $id; ?>" method=post>
            <textarea name="input" id="" cols="1000" rows="1000" placeholder="Enter the input here: " value=""></textarea>
            <input type="submit" name="submit">
        </form>
    </div>
</body>

</html>