a=int('4')
b=int('5')
print(a*b)

    