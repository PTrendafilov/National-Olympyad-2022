int a = int('5');
int b = int('17');

print(a*b)