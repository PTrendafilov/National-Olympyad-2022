a='5'
print(a)

    