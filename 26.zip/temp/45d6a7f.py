a='hello'
print(a)

    