sum=0
for i in range(5):print(f'\nnum=int(input())\nsum+=num')
print(sum)
