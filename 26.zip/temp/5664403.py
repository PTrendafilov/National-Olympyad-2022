a=int('158')
b=int('165')
print(min(a,b))