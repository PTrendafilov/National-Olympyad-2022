a=int('25')
b=int('378')
print(max(a,b))

    