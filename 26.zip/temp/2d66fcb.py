str='hello'
print(str)

    