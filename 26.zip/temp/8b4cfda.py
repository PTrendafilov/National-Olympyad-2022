a=int('5')
b=int('17')
print(a+b)

    