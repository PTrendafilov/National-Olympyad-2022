n=5
sum=0

num=int('4')
sum+=num

num=int('8')
sum+=num

num=int('5')
sum+=num

num=int('9')
sum+=num

num=int('15')
sum+=num
0

print(sum)

    