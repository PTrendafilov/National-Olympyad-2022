
ars=int('5')
bu=int('17')
print(ars)
    