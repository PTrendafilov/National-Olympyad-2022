a='5'
b='17'
print(int(a)+int(b))

        