a=int('158')
b=int('155')
c=int('300')
print(a+b-c)


    