int a = '5'
int b = '17'
print(a*b)

    