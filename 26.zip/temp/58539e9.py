a=int('5')
b=int('17')
print(a+b)
a=int(input())
b=int(input())
print(a+b)
    