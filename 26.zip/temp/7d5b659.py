a='5'
b='17'
c=a+int(b)
print(c)

        