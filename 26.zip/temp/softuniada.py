a=int(input())
b=int(input())
for i in range(a,b+1):
    for j in range(a,i):
        if i%j==0:
            prime=False
            break
        else:
            prime=True
        if prime:
         print(i," ")