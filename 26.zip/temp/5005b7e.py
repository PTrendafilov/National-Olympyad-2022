a='5'
b='17'
c=int(a)+int(b)
print(c)

        