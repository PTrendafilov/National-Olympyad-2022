a=int('25')
b=int('378')
print((a,b))

    