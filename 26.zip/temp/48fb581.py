a='5'
b='17'
print(a+b)

        