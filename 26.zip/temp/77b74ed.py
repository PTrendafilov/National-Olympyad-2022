n=5
sum=0
for i in range(n):print(f'\nnum=int(input())\nsum+=num')
print(sum)

